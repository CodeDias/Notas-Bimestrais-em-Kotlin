    package com.example.notasbimestrais

    import android.os.Bundle
    import android.widget.Button
    import android.widget.EditText
    import android.widget.TextView
    import androidx.activity.enableEdgeToEdge
    import androidx.appcompat.app.AppCompatActivity
    import androidx.core.view.ViewCompat
    import androidx.core.view.WindowInsetsCompat
    import kotlin.random.Random

    class MainActivity : AppCompatActivity() {
        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            enableEdgeToEdge()
            setContentView(R.layout.activity_main)


            ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
                val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
                insets
            }

            val nota1 = findViewById<EditText>(R.id.et_nota1)
            val nota2 = findViewById<EditText>(R.id.et_nota2)
            val nota3 = findViewById<EditText>(R.id.et_nota3)
            val nota4 = findViewById<EditText>(R.id.et_nota4)

            val btn_calcular = findViewById<Button>(R.id.btn_calcular)
            btn_calcular.setOnClickListener {
                // Extrair valores dos EditText e converter para Int
                val nota1Int = nota1.text.toString().toIntOrNull() ?: 0
                val nota2Int = nota2.text.toString().toIntOrNull() ?: 0
                val nota3Int = nota3.text.toString().toIntOrNull() ?: 0
                val nota4Int = nota4.text.toString().toIntOrNull() ?: 0

                // Passar os valores inteiros para a função calcular
                calcular(nota1Int, nota2Int, nota3Int, nota4Int)
            }
        }




        fun calcular(nota1: Int ,nota2: Int ,nota3: Int ,nota4: Int ){

            val tv_resultado = findViewById<TextView>(R.id.tv_resultado)
            val media = ((nota1 + nota2 + nota3 + nota4) / 4) // calcular a média

            tv_resultado.setText("a média das notas é:  ${media}")

        }
    }

